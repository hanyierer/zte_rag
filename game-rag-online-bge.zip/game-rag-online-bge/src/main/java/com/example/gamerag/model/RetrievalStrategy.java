package com.example.gamerag.model;

public enum RetrievalStrategy {
    VECTOR_FIRST,
    KEYWORD_FIRST,
    HYBRID,
    EXACT_MATCH
}
