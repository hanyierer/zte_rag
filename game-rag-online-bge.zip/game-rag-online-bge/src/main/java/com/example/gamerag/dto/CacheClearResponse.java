package com.example.gamerag.dto;

public record CacheClearResponse(boolean success, String message) {
}
