package com.example.gamerag.model;

public enum RecallChannel {
    DENSE_VECTOR,
    SPARSE_BM25,
    KEYWORD_QUERY
}
