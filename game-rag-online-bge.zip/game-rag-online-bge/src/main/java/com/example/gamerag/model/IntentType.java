package com.example.gamerag.model;

public enum IntentType {
    QUEST_GUIDE,
    ITEM_QUERY,
    CHARACTER_BUILD,
    MAP_LOCATION,
    BOSS_STRATEGY,
    GAME_MECHANIC,
    PATCH_OR_VERSION,
    LORE,
    TROUBLESHOOTING,
    GENERAL_QA
}
